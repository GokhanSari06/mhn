#!/usr/bin/env python


if __name__ == '__main__':
    from mhn import mhn
    mhn.run(debug=False, host='0.0.0.0', port=8000)
