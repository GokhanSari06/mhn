def format_date(dt):
    return dt.strftime('%Y-%m-%d %H:%M:%S')
