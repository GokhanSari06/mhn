DEFAULT_FLAG_URL = '/static/img/unknown.png'
