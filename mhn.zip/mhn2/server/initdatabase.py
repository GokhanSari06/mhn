from mhn import create_clean_db


if __name__ == '__main__':
    create_clean_db()
