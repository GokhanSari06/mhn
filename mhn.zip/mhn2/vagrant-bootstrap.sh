#!/bin/bash

/vagrant/install.sh
